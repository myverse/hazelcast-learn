package com.dabaizi.sp.controller;

import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.locks.Lock;

@RestController
public class HelloController {
    @Value("${eureka.instance.metadata-map.zone}")
    private String currentZone;

    @Value("${spring.cloud.client.ip-address}")
    private String currentIP;

    @Value("${server.port}")
    private String port;

    @RequestMapping(value = "/service/hello", method = RequestMethod.GET)
    public String hello() {

        HazelcastInstance hazelcastInstance = Hazelcast.newHazelcastInstance();

        Lock lock = hazelcastInstance.getCPSubsystem().getLock("myLock");
        lock.lock();
        try {
            // do something here
        } finally {
            lock.unlock();
        }

        return "This is service from ip:" + currentIP + " zone:【" + currentZone + "】port: 【" + port + "】";
    }
}
