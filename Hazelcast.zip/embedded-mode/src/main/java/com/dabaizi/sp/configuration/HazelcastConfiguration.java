package com.dabaizi.sp.configuration;

import com.hazelcast.config.Config;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.eureka.one.EurekaOneDiscoveryStrategyFactory;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class HazelcastConfiguration {

    @Value("${hazelcast.port:5701}")
    private int hazelcastPort;

    @Value("${spring.application.name}")
    private String applicationName;

    @Bean
    public Config hazelcastConfig(EurekaClient eurekaClient) {

        Application application = eurekaClient.getApplication(applicationName);
        List<InstanceInfo> instancesAsIsFromEureka = application.getInstancesAsIsFromEureka();
        for (InstanceInfo info : instancesAsIsFromEureka) {
            System.out.println(info.getIPAddr());
        }

        EurekaOneDiscoveryStrategyFactory.setEurekaClient(eurekaClient);
        Config config = new Config();
        config.getNetworkConfig().setPort(hazelcastPort);
        config.getNetworkConfig().getJoin().getMulticastConfig().setEnabled(false);
        config.getNetworkConfig().getJoin().getTcpIpConfig().setEnabled(false);
        config.getNetworkConfig().getJoin().getEurekaConfig()
                .setEnabled(true)
                .setProperty("self-registration", "true")
                .setProperty("namespace", "hazelcast")
                .setProperty("use-metadata-for-host-and-port", "true");
        return config;
    }

    @Bean
    public HazelcastInstance getInstance(Config config) {
        HazelcastInstance instance = Hazelcast.newHazelcastInstance(config);
        return instance;
    }
}
